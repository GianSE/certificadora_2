import network
import time
from machine import Pin
import dht
import ujson
from umqtt.simple import MQTTClient

# Configuração do Sensor
sensor = dht.DHT22(Pin(15))

# 1. Conectar no Wi-Fi Virtual do Wokwi
print("Conectando ao Wi-Fi...", end="")
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect('Wokwi-GUEST', '')
while not wifi.isconnected():
    print(".", end="")
    time.sleep(0.1)
print(" Conectado!")

# 2. Configurar MQTT
# Tópico personalizado com SEU nome
MQTT_BROKER = "test.mosquitto.org"
MQTT_TOPIC = "gian/projeto/sensor"
CLIENT_ID = "esp32-gian-id"

print(f"Conectando ao Broker MQTT {MQTT_BROKER}...", end="")
client = MQTTClient(CLIENT_ID, MQTT_BROKER)
client.connect()
print(" Conectado!")

while True:
    print("Lendo sensor...")
    sensor.measure() 
    temp = sensor.temperature()
    hum = sensor.humidity()
    
    # Cria o JSON
    mensagem = ujson.dumps({
        "temperatura": temp,
        "umidade": hum
    })
    
    print(f"Enviando para {MQTT_TOPIC}: {mensagem}")
    client.publish(MQTT_TOPIC, mensagem)
    
    time.sleep(2)